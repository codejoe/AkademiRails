New Campus
=========
Table
  - College
  - Faculty
  - Major
  - Semester
  - Course
  - Lecturer
  - Student